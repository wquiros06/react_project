import React from 'react'

const Notfound = () => <h1>Página no encontrada</h1>

export default Notfound